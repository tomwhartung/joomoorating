<?php
/**
 * @package		Joomla
 * @subpackage	Content
 * @copyright	Copyright (C) 2010 - Tom Hartung.  All rights reserved.
 * @license		TBD.
 */

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

// // This is a ContentViewFrontpage object
// $this_class = get_class( $this );
// print "Loading plgContentJoomoofixedrating.php: this class = " . $this_class . "<br />\n";

/**
 * Plugin for Joomoo Rating
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.5
 */
class plgContentJoomoofixedrating extends JPlugin
{
	/**
	 * placeholder regular expression indicating we want to place a constant, fixed rating into this article
	 * value is JOOMOO_FIXED_RATING_REGEX ensconced in delimiters; JOOMOO_FIXED_RATING_REGEX defined in
	 *    components/com_joomoorating/assets/constants.php
	 * @access private
	 * @var string
	 * @note we use a <br ...> tag so if plugin is missing or disabled we just get some whitespace
	 */
	private $_placeholderRegEx = null;
	/**
	 * parameters for this plugin - NOT the params for the article!
	 * @var JParameter object
	 */
	private $_pluginParams = null;
	/**
	 * text we add to article or return to gallery image view
	 * @var string
	 */
	private $_ratingText;
	/**
	 * id of article in content table, or 0 if not processing content
	 * @var int
	 */
	private $_contentid = 0;
	/**
	 * id of image row in joomoo galleryimages table, or 0 if not processing a gallery image
	 * @var int
	 */
	private $_galleryimageid = 0;
	/**
	 * rating bar color
	 * @var int
	 */
	private $_barColor;
	/**
	 * rating bar background
	 * @var int
	 */
	private $_barBackground;
	/**
	 * file path: combination of rating bar color and rating bar background
	 * @var int
	 * @note eg. 'blue_on_white' or 'yellow_on_transparent'
	 */
	private $_barFilePath;
	/**
	 * constant part of file path and name of rating bar images
	 * @var string
	 */
	private $_imageFileRoot;
	/**
	 * the rating
	 * @var int
	 */
	private $_ratingValue;
	/**
	 * caption used for table containing the rating bars
	 * @var int
	 */
	private $_ratingCaption;
	/**
	 * subtitle for display under the table containing the rating bars
	 * @var int
	 */
	private $_ratingSubtitle;

	/**
	 * Constructor
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	public function plgContentJoomoofixedrating( &$subject, $params )
	{
		parent::__construct( $subject, $params );

		global $mainframe;                     // JSite object

		//
		// Note that we want these to look just like the rating bars, so we use a lot of those files
		//
		$document =& JFactory::getDocument();  // JDocumentHTML object
		$document->addStyleSheet( DS.'components'.DS.'com_joomoobase'.DS.'assets'.DS.'joomoobase.css' );
		$document->addStyleSheet( DS.'components'.DS.'com_joomoorating'.DS.'assets'.DS.'joomoorating.css' );

		$baseConstantsFilePath = JPATH_SITE.DS.'components'.DS.'com_joomoobase'.DS.'assets'.DS.'constants.php';
		$constantsFilePath = JPATH_SITE.DS.'components'.DS.'com_joomoorating'.DS.'assets'.DS.'constants.php';
		require_once( $baseConstantsFilePath );
		require_once( $constantsFilePath );

		$this->_placeholderRegEx = '&' . JOOMOO_FIXED_RATING_REGEX . '&';
		$plugin =& JPluginHelper::getPlugin( 'content', 'joomoofixedrating' );
		$this->_pluginParams = new JParameter( $plugin->params );
	}

	//
	// --------------------------------------------------------------------------------------------
	// Main driver method that prints the rating, adding it to the article when it's being prepared
	// --------------------------------------------------------------------------------------------
	// It is followed by the private methods it uses
	//
	/**
	 * Fixed ratings are available for selected articles only, so we require that the placeholder be present
	 * if placeholder is present, generate rating and replace the placeholder in the article text
	 * else - don't change the article
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 * @access	public
	 * @return	string
	 */
	public function onPrepareContent( &$article, &$params=null, $limitstart=null )
	{
		global $mainframe;
		$this->_setIds( $article );
		$this->_ratingText = '';         // substituted for placeholder when processing a content article
		$returnText = '';                // returned to caller when processing a joomoo gallery image

		//
		// check for the place-holder
		// if we need it we generate the fixed rating and just replace the placeholder with it
		//
		$articleHasPlaceholder = preg_match( $this->_placeholderRegEx, $article->text, $matches );
		$articleHasPlaceholder ?
			$ratingOkForThisArticle = TRUE : $ratingOkForThisArticle = FALSE;

		//	$article->text = '<br />ratingOkForThisArticle = ' . $ratingOkForThisArticle . '<br />' . $article->text;

		if ( $ratingOkForThisArticle )
		{
			$this->_setRatingVariables( $matches[1] );   // matches[1] might contain some overrides
			$this->_ratingText .= $this->_getRatingXhtml( $article );
			if ( $this->_contentid > 0 )
			{
				$article->text = preg_replace( $this->_placeholderRegEx, $this->_ratingText, $article->text );
			}
			else
			{
				$returnText = $this->_ratingText;        // when processing a gallery image, return the rating xhtml
			}
		}

		return $returnText;
	}
	/**
	 * set the *id member variables: contentid and galleryimageid
	 * @access private
	 * @return void
	 */
	private function _setIds( $article )
	{
		if ( isset($article->galleryimageid) && 0 < $article->galleryimageid )
		{
			$this->_contentid = 0;
			$this->_galleryimageid = $article->galleryimageid;
		}
		else if ( isset($article->id) && 0 < $article->id )
		{
			$this->_contentid = $article->id;
			$this->_galleryimageid = 0;
		}
		else
		{
			$this->_contentid = 0;
			$this->_galleryimageid = 0;
		}
	}
	/**
	 * set variables used to display the rating
	 * @access private
	 * @return void
	 */
	private function _setRatingVariables( $overridesString )
	{
		$this->_setImageFileRoot( );
		$this->_ratingValue = $this->_pluginParams->get('rating_value');
		$this->_ratingSubtitle = $this->_pluginParams->get('rating_subtitle');

		//	$this->_ratingText .= '<br />overridesString = ' . $overridesString . '<br />';

		if ( $overridesString != null && 0 < strlen($overridesString) )
		{
			$overridesArray = explode( JOOMOO_FIXED_OVERRIDES_DELIMITER, $overridesString );
			foreach ( $overridesArray as $anOverride )
			{
				$anOverrideArray = explode( '=', $anOverride );
				$anOverrideName = trim( $anOverrideArray[0] );
				$anOverrideValue = trim( $anOverrideArray[1], "'\"`" );
				switch( $anOverrideName )
				{
					case 'rating_value':
						if ( JOOMOO_RATING_MINIMUM <= $anOverrideValue && $anOverrideValue <= JOOMOO_RATING_MAXIMUM )
						{
							$this->_ratingValue = $anOverrideValue;
						}
						break;
					case 'rating_subtitle':
						$this->_ratingSubtitle = $anOverrideValue;
						break;
				}
			}
		}

		$rating_label = $this->_pluginParams->get('rating_label');
		$captionClassAttr = 'class="joomoorating_current_value" ';
		$this->_ratingCaption = $rating_label . ': ' .
			'<span ' . $captionClassAttr . '>' . $this->_ratingValue . '</span>/' . JOOMOO_RATING_MAXIMUM;
	}
	/**
	 * set the color of the bars used in the rating
	 * @access private
	 * @return void
	 */
	private function _setImageFileRoot( )
	{
		switch ( $this->_pluginParams->get('rating_bar_color') )
		{
			case JOOMOO_RATING_BLUE:
				$this->_barColor = 'blue';
				break;
			case JOOMOO_RATING_GREEN:
				$this->_barColor = 'green';
				break;
			case JOOMOO_RATING_RED:
				$this->_barColor = 'red';
				break;
			case JOOMOO_RATING_YELLOW:
				$this->_barColor = 'yellow';
				break;
			case JOOMOO_RATING_WHITE:
				$this->_barColor = 'white';
				break;
			default:
			case JOOMOO_RATING_BLACK:
				$this->_barColor = 'black';
				break;
		}

		switch ( $this->_pluginParams->get('rating_bar_background') )
		{
			case JOOMOO_RATING_WHITE:
				$this->_barBackground = 'white';
				break;
			case JOOMOO_RATING_TRANSPARENT:
				$this->_barBackground = 'transparent';
				break;
			default:
			case JOOMOO_RATING_BLACK:
				$this->_barBackground = 'black';
				break;
		}

		$this->_barFilePath = $this->_barColor . '_on_' . $this->_barBackground;

		$this->_imageFileRoot = DS. 'components' .DS. 'com_joomoorating' .DS.
			'images' .DS. 'bars' .DS. $this->_barFilePath .DS. $this->_barFilePath;
	}
	/**
	 * assembles xhtml for fixed rating
	 * @access private
	 * @return string xhtml containing rating
	 */
	private function _getRatingXhtml( $article )
	{
		$ratingValue = $this->_ratingValue;
		$ratingXhtml  = '';

		$ratingXhtml .= '<center>' . "\n";
		$ratingXhtml .= ' <table class="joomoorating_bars">' . "\n";
		$ratingXhtml .= '  <caption>' . $this->_ratingCaption . '</caption>' . "\n";
		$ratingXhtml .= '  <tr>' . "\n";

		for ( $ratingSub = JOOMOO_RATING_MINIMUM; $ratingSub <= JOOMOO_RATING_MAXIMUM; $ratingSub++ )
		{
			$lightFileName  = $this->_imageFileRoot . '-light-'  . $ratingSub . '.gif';
			$normalFileName = $this->_imageFileRoot . '-normal-' . $ratingSub . '.gif';
			$ratingValue == $ratingSub ? $rootedFileName = $normalFileName : $rootedFileName = $lightFileName;
			$imgTag = '     <img ' . 'class="joomoorating_bar" src="' . $rootedFileName . '" />' . "\n";
			$ratingXhtml .= '   <td class="joomoorating_bar">' . "\n" . $imgTag . '   </td>' . "\n";
		}

		$ratingXhtml .= '  </tr>' . "\n";

		if ( 0 < strlen($this->_ratingSubtitle) && 0 < $this->_galleryimageid )
		{
			$this->_ratingSubtitle = preg_replace( '&article&', 'gallery image', $this->_ratingSubtitle );
		}
		$ratingXhtml .= '  <tr><td colspan="' . (JOOMOO_RATING_MAXIMUM) . '" class="joomoorating_vote_count">' .
			$this->_ratingSubtitle . '</td></tr>' . "\n";

		$ratingXhtml .= ' </table>' . "\n";
		$ratingXhtml .= '</center>' . "\n";

		return $ratingXhtml;
	}
}
