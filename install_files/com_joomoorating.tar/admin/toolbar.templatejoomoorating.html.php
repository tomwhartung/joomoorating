<?php
/**
 * @author      Tom Hartung <webmaster@tomhartung.com>
 * @package     Joomla
 * @subpackage  joomoorating
 * @copyright   Copyright (C) 2010 Tom Hartung. All rights reserved.
 * @since       1.5
 * @license     GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

/**
 * @package     Joomla
 * @subpackage  joomoorating
 */
class TOOLBAR_joomoorating
{
	/**
	 * Setup joomoorating toolbars
	 */
	function _DEFAULT()
	{
	//	JToolBarHelper::deleteList( "Are you sure you want to delete these rows?" );
	}
}
?>
